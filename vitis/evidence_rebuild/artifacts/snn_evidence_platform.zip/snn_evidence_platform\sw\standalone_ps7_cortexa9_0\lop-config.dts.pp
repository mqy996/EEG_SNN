# 1 "D:/eeg_fpga/snn_hybrid_eeg/vitis/e1/snn_evidence_platform/export/snn_evidence_platform/sw/standalone_ps7_cortexa9_0/lop-config.dts"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "D:/eeg_fpga/snn_hybrid_eeg/vitis/e1/snn_evidence_platform/export/snn_evidence_platform/sw/standalone_ps7_cortexa9_0/lop-config.dts"

/dts-v1/;
/ {
        compatible = "system-device-tree-v1,lop";
        lops {
                lop_0 {
                        compatible = "system-device-tree-v1,lop,load";
                        load = "assists/baremetal_validate_comp_xlnx.py";
                };

                lop_1 {
                    compatible = "system-device-tree-v1,lop,assist-v1";
                    node = "/";
                    outdir = "D:/eeg_fpga/snn_hybrid_eeg/vitis/e1/snn_evidence_platform/export/snn_evidence_platform/sw/standalone_ps7_cortexa9_0";
                    id = "module,baremetal_validate_comp_xlnx";
                    options = "ps7_cortexa9_0 D:/vitis/2025.1/Vitis/data/embeddedsw/lib/sw_apps/hello_world/src D:/eeg_fpga/snn_hybrid_eeg/vitis/e1/_ide/.wsdata/.repo.yaml";
                };

        };
    };
